*** Settings ***
Documentation   Opdracht A:
         ...    - Maak een lijst
         ...    - Voeg er een item aan toe
         ...    - Verwijder een item
         ...    - Lees één waarde uit
         ...    
         ...    Bonus: Maak een nieuwe lijst die gesorteerd is op basis van het origineel     

Library    Collections    


*** Test Cases ***
Opdracht2.1a
    @{list}    Create List    App    Noot    Mies    Beer    Wim
    Append To List    ${list}    Item5
    Remove From List    ${list}    3
    Get From List    ${list}    0
    Log List    ${list}    level=CONSOLE

    @{list_kopie}    Copy List    ${list}
    Sort List    ${list_kopie}
    Log List    ${list_kopie}    level=CONSOLE
    
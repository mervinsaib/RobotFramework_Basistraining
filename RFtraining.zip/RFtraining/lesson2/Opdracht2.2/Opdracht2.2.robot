*** Settings ***
Documentation   Opdracht met Dictionaries:
         ...    - Voeg een (key-value) item toe
         ...    - Verwijder een (key-value) item
         ...    - Lees één waarde uit
         ...    Bonus:
         ...    - Toon aan dat een dictionary een waarde bevat 

Library    Collections    


*** Variables ***


*** Test Cases ***
Opdracht2.2
    ${dict}    Create Dictionary    Jan=Den Haag    Peter=Rotterdam    Joost=Lopik    Marie=Arnhem
    Set To Dictionary    ${dict}    Henk=Amsterdam
    Remove From Dictionary    ${dict}    Jan
    Log    ${dict.Marie}
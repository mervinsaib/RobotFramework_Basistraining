*** Settings ***
Documentation    Voeg tags toe aan de testsuite, 
...    gebruik deze om een aantal testgevallen uit te voeren.
...    - inclusief
...    - exclusief
Test Tags    inclusief

*** Test Cases ***
Opdracht2.4a
    [Tags]    exclusief
    Log    ${TEST_NAME}

Opdracht2.4b
    [Tags]    exclusief
    Log    ${TEST_NAME}    

Opdracht2.4c
    Log    ${TEST_NAME}    

Opdracht2.4d
    [Tags]    exclusief
    Log    ${TEST_NAME}

#robot -i exclusief .\Opdracht2.4.robot
#robot -i exclusief .\Opdracht2.4.robot
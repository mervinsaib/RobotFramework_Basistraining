*** Settings ***  
Documentation    Bij een random gegenereerde lijst doe het volgende:
...              - Schrijf de voorbeeldlijst naar een .csv bestand.
...              - Bonus: zorg ervoor dat het bestand automatisch wordt opgeruimd
...              - Bonus 2: Zorg ervoor dat er max 10 woorden per regel staan
Library    OperatingSystem

*** Variables ***
@{voorbeeldlijst}    Lorem    ipsum    dolor    sit    amet    consectetur    adipisicing    elit    sed    do    eiusmod    tempor    incididunt    ut    labore    et    dolore    magna    aliqua
${count}=    ${0}
 
*** Keywords ***
Verwijder csv
    Remove File    ${CURDIR}${/}voorbeeld.csv
 
*** Test Cases ***
Opdracht3.6
    FOR    ${element}    IN    @{voorbeeldlijst}
        IF    ${count} % 10 == 0 and ${count} != 0
            Append To File    ${CURDIR}${/}voorbeeld.csv    \n
        END
        ${count}    Set Variable    ${count+1}
        Append To File    ${CURDIR}${/}voorbeeld.csv    ${element}${SPACE}
       
    END

TestQ
    @{rando}    This keyword returns random numbers
    ${listlength}    Get Length    ${rando}
 
    FOR  ${index}    IN RANGE     ${listlength}
        IF  ${rando}[${index}] == 5
            Log    number found on ${index}    level=console
            BREAK
        END
    END
 
    ${found}    Get Index From List    ${rando}    ${5}
    log    ${rando}
    Log    number found on ${found}    level=console
*** Settings ***  
Documentation    Robot ondersteund verschillende vormen van validaties, één daarvan is een zogenaamde 'multi-line String Comparison'.
          ...    Voer test uit om twee csv bestanden met elkaar te vergelijken. Gebruik daarbij de Multiline String Comparison.
          ...    Voer daarna nog een andere test uit die op lijn niveau de bestanden vergelijkt.
          ...    
          ...    Bonus opdracht: Log in een apart bestand de positie van een regel in het eerste en in het tweede bestand.
Library    OperatingSystem
Library    Collections
Library    String

*** Variables ***
${Expected_1}    ${CURDIR}//Source 1.csv
${Actual_1}      ${CURDIR}//Actual 1.csv
${Expected_2}    ${CURDIR}//Source 2.csv
${Actual_2}      ${CURDIR}//Actual 2.csv

*** Test Cases ***
Opdracht3.7a Vergelijk de eerste set bestanden
	Comment    laad twee bestanden in en vergelijk deze
    ${fileExpected}=    Get File    ${Expected_1}
    ${fileActual}=      Get File    ${Actual_1}
    Should be Equal    ${fileExpected}    ${fileActual}
    
Opdracht3.7b Vergelijk de tweede set bestanden
	Comment    laad twee bestanden in en vergelijk deze
    ${fileExpected}=    Get File    ${Expected_2}
    ${fileActual}=      Get File    ${Actual_2}
    Should be Equal    ${fileExpected}    ${fileActual}

Opdracht3.7c Vergelijk de tweede set bestanden op regel niveau
     Comment    Ondanks dat de vergelijking op bestand niveau een fout terug geeft, bevatten beide bestanden dezelfde informatie.
    ...        schrijf een test die dit bewijst.
    ${fileExpected}=    Get File    ${Expected_2}
    ${fileActual}=      Get File    ${Actual_2}
    ${fileExpected}=    Split To Lines    ${fileExpected}
    ${fileActual}=    Split To Lines    ${fileActual}
    Sort List    ${fileExpected}
    Sort List    ${fileActual}
    Should be Equal    ${fileExpected}    ${fileActual}

Opdracht3.7 bonus Vergelijk de tweede set bestanden op regel niveau en geef zowel de oude als de nieuwe positie terug in een apart log bestand
    Comment    Maak gebruik van je opgedane kennis over loopjes en controles om deze opdracht te maken
    Remove File    ${CURDIR}\\log bestand.txt
    ${fileExpected}=    Get File    ${Expected_2}
    ${fileActual}=      Get File    ${Actual_2}
    ${fileExpected}=    Split To Lines    ${fileExpected}
    ${fileActual}=    Split To Lines    ${fileActual}
    ${numberOfRows}    Get Length    ${fileExpected}
    Append To File    ${CURDIR}\\log bestand.txt    Dit is een log bestand \n
    FOR    ${counter1}    IN RANGE    0    ${numberOfRows}
        FOR    ${counter2}    IN RANGE    0    ${numberOfRows}
            IF    '${fileExpected}[${counter1}]' == '${fileActual}[${counter2}]'
                Append To File    ${CURDIR}\\log bestand.txt    Regel ${counter1+1} van het bron bestand staat op positie ${counter2+1} van het nieuwe bestand \n
                Exit For Loop
            END
        END
    END

ADUIDIUAW
      ${ExpectedFile2}=    Get File    ${Expected_2}
    ${ActualFile2}=    Get File    ${Actual_2}
    ${ExpectedLines}=    Split To Lines   ${ExpectedFile2}
    ${ActualLines}=    Split To Lines    ${ActualFile2}
    ${Length}=     Get Length    ${ExpectedLines}
 
    FOR    ${element}    IN RANGE    0    ${Length}
        FOR    ${element2}    IN RANGE    ${Length}
                    ${areEqual}=    Should Be Equal    '${ExpectedLines}[${element}]'    '${ExpectedLines}[${element}]'
                    IF    '${ExpectedLines}[${element}]' == '${ExpectedLines}[${element}]'
                        Append To File    ${CURDIR}${/}Result.csv    ${element} ${element2}
                    END
        END
 
       
    END
    Sort List    ${ExpectedLines}
    Sort List    ${ActualLines}
*** Settings ***  
Library         Collections
Documentation    Gegegeven een lijst met auto namen, doe er de volgende dingen mee:
...              Loop met een FOR loop door de lijst en print van elke auto de naam 
...              Bonus: sorteer de lijst in omgekeerde volgorde en print de naam van elke auto

*** Variables ***
@{Lijst met auto's}    Mazda-3    Ford Focus    Honda Civic    Range Rover Sport     Range Rover E-Sport    Honda Civic Hybrid    Ford Focus ST

*** Test Cases ***
Opdracht3.1
    FOR    ${auto}    IN    @{Lijst met auto's}
        Log    ${auto}
    END

Opdracht 3.1 bonus
    @{sort_list}    Copy List    ${Lijst met auto's}
    Reverse List    ${sort_list}
    FOR    ${auto}    IN    @{sort_list}
        Log    ${auto}
    END
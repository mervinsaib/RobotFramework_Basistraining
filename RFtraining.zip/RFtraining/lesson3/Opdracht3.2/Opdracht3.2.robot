*** Settings ***  
Documentation    Bij een random gegenereerde lijst doe het volgende:
...              - Bepaal de lengte
...              - Kies een nummer en kijk op welke positie deze staat
...              - Stop met zoeken zodra de verwachte waarde is gevonden
...              - Bonus: Zoek uit met welk keyword je het bovenstaande in één keer kan doen

Resource   Resources/RandomGenerator.resource

*** Test Cases ***
Opdracht3.2
    @{lijst}    This keyword returns random numbers
    ${length}    Get Length    ${lijst}
    FOR    ${item}    IN    @{lijst}
        IF    ${item}==${22}
            log    ${item}
            ${index}    Get Index From List    ${lijst}    ${item}
            Log    ${index}
            BREAK
        END
    END

Opdracht3.2twee
    ${list}    This keyword returns random numbers
    ${length}    Get Length    ${list}
    FOR    ${item}    IN RANGE    0    ${length}
        IF    ${list}[${item}]==${22}
            log    ${list}[${item}]
            BREAK
        END
    END

Opdracht3.2drie
    ${list}    This keyword returns random numbers
    ${length}    Get Length    ${list}
    log    De lengte van de lijst is ${length}
    FOR    ${index}    IN RANGE    ${length}
        ${current_number}=    Get From List    ${list}    ${index}
        IF    ${current_number}==${13}    
            Log    Found number 13 at position ${index}  
            BREAK
        END
    END

Opdracht3.2bonus
    ${list}    This keyword returns random numbers
    ${nummer}    Get Index From List    ${list}    ${22}


DKAUBWD
    @{rando}    This keyword returns random numbers
    ${listlength}    Get Length    ${rando}
 
    FOR  ${index}    IN RANGE     ${listlength}
        IF  ${rando}[${index}] == 5
            Log    number found on ${index}    level=console
            BREAK
        END
    END
 
    ${found}    Get Index From List    ${rando}    ${5}
    log    ${rando}
    Log    number found on ${found}    level=console

*** Keywords ***
This keyword returns random numbers
    ${ReturnedList} =    Random Generator
    Log list    ${ReturnedList}
    [Return]    ${ReturnedList}
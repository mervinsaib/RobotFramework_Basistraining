*** Settings ***  
Documentation    Zorg dat een aantal stappen in je testgeval door functies / keywords worden uitgevoerd.
          ...    Pas dit toe bij de testgevallen uit de eerdere opdracht.

Library    Browser    

*** Variables ***
${url}=                   http://localhost:7272
${browser}=               chromium
${loginnaam}=             demo
${correct_wachtwoord}=    mode
${foutief_wachtwoord}=    edom
${welkomstpagina}=        Welcome Page DEV
${foutpagina}=            Error Page DEV

*** Test Cases ***
Log succesvol in
    Open login scherm
    Vul login gegevens in    ${loginnaam}    ${correct_wachtwoord}
    Valideer landingspagina    ${welkomstpagina}
    
Log in met een foutief wachtwoord
    Open login scherm
    Vul login gegevens in    ${loginnaam}    ${foutief_wachtwoord}
    Valideer landingspagina    ${foutpagina}
    
*** Keywords ***
Open login scherm
    Open Browser     ${url}    ${browser}

Vul login gegevens in
    [Arguments]    ${username}    ${password}
    Type Text       id=username_field    ${loginnaam}
    Type Secret       id=password_field    $password
    Click     id=login_button

Valideer landingspagina
    [Arguments]    ${type}
    Get Title    ==  ${type}
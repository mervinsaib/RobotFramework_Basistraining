*** Settings ***
Resource    ../Opdracht1.5/Opdracht1.5.resource

*** Test Cases ***
Log succesvol in
    Given De login pagina is open
    When Valide inloggegevens zijn ingevoerd
    Then Welkomstpagina is zichtbaar
    
Log in met een foutief wachtwoord
    Given De login pagina is open
    When Invalide inloggegevens zijn ingevoerd
    Then Foutpagina is zichtbaar
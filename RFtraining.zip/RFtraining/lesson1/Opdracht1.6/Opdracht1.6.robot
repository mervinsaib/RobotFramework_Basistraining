*** Settings ***
Documentation    Verplaats alle keywords, libraries en variabelen uit je test suite naar resource bestand(en).
           ...   Importeer één of meerdere resource bestanden om testsuite weer te laten werken.​

Library    Browser
Resource    Opdracht1.6.resource




*** Test Cases ***
Log succesvol in    Succesvol
    
Log in met een foutief wachtwoord    Foutief

*** Settings ***
Documentation    Hieronder staan de twee validatie tests uit de eerdere opdracht. 
          ...    Maak je test flexibeler, gebruik variabelen voor:​
          ...    - Browser​
          ...    - Username veld​
          ...    - Password veld​
          ...    - Etc.


Library     Browser    

*** Variables ***
${browser}    chromium
${url}    http://localhost:7272
${username_locator}    id=username_field
${password_locator}    id=password_field
${login_button}    id=login_button    

*** Test Cases ***
Log succesvol in
    Open Browser    ${url}
    Type Text        ${username_locator}    demo
    Type Text        ${password_locator}    mode
    Click    ${login_button}
    Get Title    ==  Welcome Page DEV
    Close Browser
    
Log in met een foutief wachtwoord
    Open Browser    ${url}
    Type Text        ${username_locator}    demo
    Type Text        ${password_locator}    edom
    Click    ${login_button}
    Get Title    ==  Error Page DEV
    Close Browser
